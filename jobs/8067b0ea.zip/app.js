const MAX_CAPACITY = 600;
const LECTURER_PASS = "admin123";

// Initialize Firebase Realtime Database
const firebaseConfig = {
  databaseURL: "https://e-exam-4e944-default-rtdb.firebaseio.com/"
};
firebase.initializeApp(firebaseConfig);
const rtdb = firebase.database();

// Sanitize Matric Numbers for Firebase keys (replaces '/' with '_')
const safeKey = (matric) => matric.replace(/[.#$\[\]\/]/g, "_");

// Live Sync Cache
let liveExam = null;
let liveStudents = [];
let liveSubmissions = {};

rtdb.ref("eexam/config").on("value", (snap) => {
  liveExam = snap.val();
});

rtdb.ref("eexam/students").on("value", (snap) => {
  const val = snap.val();
  liveStudents = val ? Object.values(val) : [];
  if (document.getElementById("lecturer-screen").classList.contains("active")) {
    renderLecturerDashboard();
  }
});

rtdb.ref("eexam/submissions").on("value", (snap) => {
  liveSubmissions = snap.val() || {};
  if (document.getElementById("lecturer-screen").classList.contains("active")) {
    renderLecturerDashboard();
  }
});

const DB = {
  getExam: () => liveExam,
  saveExam: (data) => rtdb.ref("eexam/config").set(data),
  getStudents: () => liveStudents,
  saveStudent: (stu) => rtdb.ref("eexam/students/" + safeKey(stu.matric)).set(stu),
  getSubmissions: () => liveSubmissions,
  saveSubmission: (sub) => rtdb.ref("eexam/submissions/" + safeKey(sub.matric)).set(sub)
};

let draftQuestions = [];
let currentStudent = null;
let shuffledQuestions = [];
let studentAnswers = {};
let currentQIndex = 0;
let violations = 0;
let examActive = false;
let timerInterval = null;
let initialHeight = window.innerHeight;

// --- AUTHENTICATION & NAVIGATION ---
function switchLoginTab(role) {
  document.getElementById("tab-student").classList.toggle("active", role === "student");
  document.getElementById("tab-lecturer").classList.toggle("active", role === "lecturer");
  document.getElementById("student-login-form").classList.toggle("hidden", role !== "student");
  document.getElementById("lecturer-login-form").classList.toggle("hidden", role !== "lecturer");
}

function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function loginLecturer(e) {
  e.preventDefault();
  const pass = document.getElementById("lec-pass").value;
  if (pass !== LECTURER_PASS) return alert("Invalid Lecturer Password.");
  showScreen("lecturer-screen");
  renderLecturerDashboard();
}

async function loginStudent(e) {
  e.preventDefault();
  const name = document.getElementById("stu-name").value.trim();
  const matric = document.getElementById("stu-matric").value.trim().toUpperCase();
  const pass = document.getElementById("stu-pass").value.trim();

  const expectedPass = matric.slice(-3);
  if (pass !== expectedPass) {
    return alert("Authentication Failed: Password must be the last 3 digits of your Matric Number.");
  }

  // Fetch latest exam directly from cloud in case page just loaded
  const examSnap = await rtdb.ref("eexam/config").once("value");
  const exam = examSnap.val();
  if (!exam || !exam.published) {
    return alert("No active exam has been published by the lecturer yet.");
  }
  liveExam = exam;

  // Check if already submitted in cloud
  const subSnap = await rtdb.ref("eexam/submissions/" + safeKey(matric)).once("value");
  if (subSnap.exists()) {
    return alert("You have already completed and submitted this exam.");
  }

  // Check capacity & auto-register student
  const students = DB.getStudents();
  let existing = students.find(s => s.matric === matric);
  if (!existing) {
    if (students.length >= MAX_CAPACITY) {
      return alert("Exam Hall Full: Maximum 600-student capacity reached.");
    }
    existing = { name, matric };
    await DB.saveStudent(existing);
  }

  currentStudent = existing;
  document.getElementById("stu-course-title").textContent = exam.course;
  document.getElementById("stu-identity").textContent = `${name} (${matric})`;
  showScreen("student-screen");
}

function logout() {
  examActive = false;
  clearInterval(timerInterval);
  exitLockdownMode();
  showScreen("auth-screen");
}

// --- LECTURER PORTAL ---
function toggleQuestionBuilder() {
  const format = document.getElementById("exam-format").value;
  document.getElementById("obj-builder").classList.toggle("hidden", format !== "objective");
  document.getElementById("theory-builder").classList.toggle("hidden", format !== "theory");
}

function addQuestion() {
  const format = document.getElementById("exam-format").value;
  if (format === "objective") {
    const q = document.getElementById("obj-q").value.trim();
    const A = document.getElementById("opt-a").value.trim();
    const B = document.getElementById("opt-b").value.trim();
    const C = document.getElementById("opt-c").value.trim();
    const D = document.getElementById("opt-d").value.trim();
    const answer = document.getElementById("obj-correct").value;

    if (!q || !A || !B || !C || !D) return alert("Fill in the question and all 4 options.");
    draftQuestions.push({ id: "Q" + (draftQuestions.length + 1), type: "objective", q, options: { A, B, C, D }, answer });

    ["obj-q", "opt-a", "opt-b", "opt-c", "opt-d"].forEach(id => document.getElementById(id).value = "");
  } else {
    const q = document.getElementById("theory-q").value.trim();
    const guide = document.getElementById("theory-guide").value.trim();
    if (!q) return alert("Enter the theory question.");
    draftQuestions.push({ id: "Q" + (draftQuestions.length + 1), type: "theory", q, guide });

    document.getElementById("theory-q").value = "";
    document.getElementById("theory-guide").value = "";
  }
  document.getElementById("q-count").textContent = draftQuestions.length;
}

async function publishExam() {
  if (draftQuestions.length === 0) return alert("Add at least 1 question before publishing.");
  const course = document.getElementById("exam-course").value.trim() || "COURSE";
  const durationMins = parseInt(document.getElementById("exam-duration").value, 10) || 30;
  const format = document.getElementById("exam-format").value;
  const endTime = Date.now() + durationMins * 60 * 1000;

  await DB.saveExam({
    course,
    format,
    durationMins,
    endTime,
    questions: draftQuestions,
    published: true
  });

  alert(`Exam Published Live to Cloud! Timer set for ${durationMins} minutes.`);
  renderLecturerDashboard();
}

async function clearExam() {
  if (!confirm("Reset exam questions and clear all student submissions from cloud?")) return;
  await rtdb.ref("eexam/config").remove();
  await rtdb.ref("eexam/submissions").remove();
  draftQuestions = [];
  document.getElementById("q-count").textContent = "0";
  renderLecturerDashboard();
}

async function registerStudent() {
  const name = document.getElementById("reg-name").value.trim();
  const matric = document.getElementById("reg-matric").value.trim().toUpperCase();
  if (!name || !matric) return alert("Enter both name and matric number.");

  const students = DB.getStudents();
  if (students.length >= MAX_CAPACITY) return alert("600-Student Capacity Reached.");
  if (students.some(s => s.matric === matric)) return alert("Student already registered.");

  await DB.saveStudent({ name, matric });
  document.getElementById("reg-name").value = "";
  document.getElementById("reg-matric").value = "";
}

function calculateGrade(percent) {
  if (percent >= 70) return "A";
  if (percent >= 60) return "B";
  if (percent >= 50) return "C";
  if (percent >= 45) return "D";
  return "F";
}

function detectPlagiarism(submissions) {
  const entries = Object.values(submissions);
  const flaggedMatrics = {};

  for (let i = 0; i < entries.length; i++) {
    for (let j = i + 1; j < entries.length; j++) {
      const s1 = entries[i];
      const s2 = entries[j];
      const text1 = Object.values(s1.answers || {}).join(" ").toLowerCase().trim();
      const text2 = Object.values(s2.answers || {}).join(" ").toLowerCase().trim();

      if (!text1 || !text2) continue;

      if (text1 === text2) {
        flaggedMatrics[s1.matric] = `100% Match with ${s2.matric}`;
        flaggedMatrics[s2.matric] = `100% Match with ${s1.matric}`;
      } else {
        const words1 = new Set(text1.split(/\s+/));
        const words2 = new Set(text2.split(/\s+/));
        const intersection = [...words1].filter(w => words2.has(w)).length;
        const union = new Set([...words1, ...words2]).size;
        const similarity = union > 0 ? intersection / union : 0;

        if (similarity >= 0.75) {
          const pct = Math.round(similarity * 100);
          flaggedMatrics[s1.matric] = `${pct}% Similar to ${s2.matric}`;
          flaggedMatrics[s2.matric] = `${pct}% Similar to ${s1.matric}`;
        }
      }
    }
  }
  return flaggedMatrics;
}

function renderLecturerDashboard() {
  const exam = DB.getExam();
  const students = DB.getStudents();
  const subs = DB.getSubmissions();
  const plagFlags = exam && exam.format === "theory" ? detectPlagiarism(subs) : {};

  document.getElementById("capacity-count").textContent = students.length;
  document.getElementById("stat-reg").textContent = students.length;
  document.getElementById("stat-sat").textContent = Object.keys(subs).length;

  let lateCount = 0;
  Object.values(subs).forEach(s => { if (s.lateOrForced) lateCount++; });
  document.getElementById("stat-late").textContent = lateCount;
  document.getElementById("stat-plag").textContent = Object.keys(plagFlags).length;

  const tbody = document.getElementById("results-tbody");
  tbody.innerHTML = "";

  students.forEach(stu => {
    const sub = subs[safeKey(stu.matric)];
    const tr = document.createElement("tr");

    if (!sub) {
      tr.innerHTML = `
        <td>${stu.matric}</td>
        <td>${stu.name}</td>
        <td><span class="badge warn">Not Submitted</span></td>
        <td>0</td>
        <td>—</td>
        <td>Pending</td>
      `;
    } else {
      const plagText = plagFlags[stu.matric]
        ? `<span class="badge danger">${plagFlags[stu.matric]}</span>`
        : "Clean";
      const scoreDisplay = exam && exam.format === "objective"
        ? `${sub.score}/${sub.total} (${sub.percent}% - Grade ${sub.grade})`
        : "Theory Submitted (Review)";

      tr.innerHTML = `
        <td>${stu.matric}</td>
        <td>${stu.name}</td>
        <td><span class="badge ${sub.lateOrForced ? 'danger' : 'safe'}">${sub.status}</span></td>
        <td>${sub.violations}</td>
        <td>${plagText}</td>
        <td><strong>${scoreDisplay}</strong></td>
      `;
    }
    tbody.appendChild(tr);
  });
}

function exportResultsCSV() {
  const students = DB.getStudents();
  const subs = DB.getSubmissions();
  let csv = "Matric Number,Full Name,Status,Violations,Score,Percentage,Grade\n";

  students.forEach(stu => {
    const sub = subs[safeKey(stu.matric)];
    if (sub) {
      csv += `"${stu.matric}","${stu.name}","${sub.status}",${sub.violations},${sub.score || 0},${sub.percent || 0}%,${sub.grade || "N/A"}\n`;
    } else {
      csv += `"${stu.matric}","${stu.name}","Absent / Did Not Submit",0,0,0%,F\n`;
    }
  });

  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "E-Exam_Results.csv";
  a.click();
}

// --- STUDENT EXAM & ANTI-CHEAT LOCKDOWN ---
function shuffleArray(arr) {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function enterLockdownMode() {
  const docEl = document.documentElement;
  if (docEl.requestFullscreen) docEl.requestFullscreen().catch(() => {});

  history.pushState(null, "", location.href);
  window.addEventListener("popstate", handleBackGesture);
  document.addEventListener("visibilitychange", handleVisibilityViolation);
  window.addEventListener("blur", handleWindowBlurViolation);
  window.addEventListener("resize", handleWindowResizeViolation);
}

function exitLockdownMode() {
  if (document.fullscreenElement && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  }
  window.removeEventListener("popstate", handleBackGesture);
  document.removeEventListener("visibilitychange", handleVisibilityViolation);
  window.removeEventListener("blur", handleWindowBlurViolation);
  window.removeEventListener("resize", handleWindowResizeViolation);
}

function handleBackGesture() {
  if (examActive) {
    history.pushState(null, "", location.href);
    registerViolation("Attempted to navigate back or exit screen.");
  }
}

function handleVisibilityViolation() {
  if (examActive && document.hidden) {
    registerViolation("Switched app or minimized screen.");
  }
}

function handleWindowBlurViolation() {
  if (examActive) {
    registerViolation("Opened floating window, split-screen, or notification shade.");
  }
}

function handleWindowResizeViolation() {
  if (examActive && window.innerHeight < initialHeight * 0.75) {
    registerViolation("Split-screen or floating window resize detected.");
  }
}

function registerViolation(reason) {
  if (!examActive) return;
  violations++;
  const badge = document.getElementById("violation-badge");
  badge.textContent = `Violations: ${violations} / 2`;
  badge.className = "badge danger";

  if (violations >= 2) {
    finalizeExam("Terminated: 2 Security Violations (" + reason + ")", true);
  } else {
    document.getElementById("warning-modal").classList.remove("hidden");
  }
}

function dismissWarning() {
  document.getElementById("warning-modal").classList.add("hidden");
  enterLockdownMode();
}

function startExamSession() {
  const exam = DB.getExam();
  shuffledQuestions = shuffleArray(exam.questions);
  studentAnswers = {};
  currentQIndex = 0;
  violations = 0;
  examActive = true;

  enterLockdownMode();
  initialHeight = window.innerHeight;

  document.getElementById("exam-intro").classList.add("hidden");
  document.getElementById("exam-active-box").classList.remove("hidden");

  renderCurrentQuestion();
  startCountdown(exam.endTime);
}

function startCountdown(endTime) {
  timerInterval = setInterval(() => {
    const remaining = endTime - Date.now();
    if (remaining <= 0) {
      clearInterval(timerInterval);
      finalizeExam("Auto-Submitted: Time Expired (Late Cutoff)", true);
      return;
    }
    const mins = Math.floor(remaining / 60000);
    const secs = Math.floor((remaining % 60000) / 1000);
    document.getElementById("stu-timer").textContent =
      `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  }, 1000);
}

function renderCurrentQuestion() {
  const qObj = shuffledQuestions[currentQIndex];
  document.getElementById("q-progress").textContent = `Question ${currentQIndex + 1} of ${shuffledQuestions.length}`;
  document.getElementById("current-q-text").textContent = qObj.q;

  const optBox = document.getElementById("stu-options-box");
  const theoryBox = document.getElementById("stu-theory-box");

  if (qObj.type === "objective") {
    optBox.classList.remove("hidden");
    theoryBox.classList.add("hidden");
    optBox.innerHTML = "";

    ["A", "B", "C", "D"].forEach(letter => {
      const div = document.createElement("div");
      div.className = "option-item" + (studentAnswers[qObj.id] === letter ? " selected" : "");
      div.textContent = `${letter}. ${qObj.options[letter]}`;
      div.onclick = () => {
        studentAnswers[qObj.id] = letter;
        renderCurrentQuestion();
      };
      optBox.appendChild(div);
    });
  } else {
    optBox.classList.add("hidden");
    theoryBox.classList.remove("hidden");
    const input = document.getElementById("stu-theory-input");
    input.value = studentAnswers[qObj.id] || "";
    input.oninput = () => {
      studentAnswers[qObj.id] = input.value;
    };
  }

  document.getElementById("prev-btn").disabled = currentQIndex === 0;
  const isLast = currentQIndex === shuffledQuestions.length - 1;
  document.getElementById("next-btn").classList.toggle("hidden", isLast);
  document.getElementById("submit-btn").classList.toggle("hidden", !isLast);
}

function prevQuestion() {
  if (currentQIndex > 0) {
    currentQIndex--;
    renderCurrentQuestion();
  }
}

function nextQuestion() {
  if (currentQIndex < shuffledQuestions.length - 1) {
    currentQIndex++;
    renderCurrentQuestion();
  }
}

function confirmSubmit() {
  if (confirm("Are you sure you want to submit? You cannot return once submitted.")) {
    finalizeExam("Submitted On Time", false);
  }
}

async function finalizeExam(statusLabel, lateOrForced) {
  examActive = false;
  clearInterval(timerInterval);
  exitLockdownMode();

  const exam = DB.getExam();
  let score = 0;
  const total = exam.questions.length;

  if (exam.format === "objective") {
    exam.questions.forEach(q => {
      if (studentAnswers[q.id] === q.answer) score++;
    });
  }

  const percent = total > 0 ? Math.round((score / total) * 100) : 0;
  const grade = calculateGrade(percent);

  await DB.saveSubmission({
    matric: currentStudent.matric,
    name: currentStudent.name,
    status: statusLabel,
    lateOrForced,
    violations,
    answers: studentAnswers,
    score,
    total,
    percent,
    grade,
    submittedAt: new Date().toISOString()
  });

  document.getElementById("warning-modal").classList.add("hidden");
  document.getElementById("exam-active-box").classList.add("hidden");
  document.getElementById("exam-submitted-box").classList.remove("hidden");
  document.getElementById("submission-reason").textContent = statusLabel;
}
